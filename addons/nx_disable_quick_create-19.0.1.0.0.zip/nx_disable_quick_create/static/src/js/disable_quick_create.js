/** @odoo-module **/

import { Many2OneField } from "@web/views/fields/many2one/many2one_field";
import { Many2ManyTagsField } from "@web/views/fields/many2many_tags/many2many_tags_field";
import { Many2XAutocomplete } from "@web/views/fields/relational_utils";
import { patch } from "@web/core/utils/patch";

// Comprehensive patch to disable quick create globally

// 1. Patch Many2OneField to disable canQuickCreate at field level
patch(Many2OneField.prototype, {
    setup() {
        super.setup(...arguments);
        // Force canQuickCreate to false in props
        if (this.props) {
            this.props.canQuickCreate = false;
        }
    },

    get canQuickCreate() {
        return false;
    },
});

// 2. Patch Many2ManyTagsField similarly
patch(Many2ManyTagsField.prototype, {
    setup() {
        super.setup(...arguments);
        if (this.props) {
            this.props.canQuickCreate = false;
        }
    },

    get canQuickCreate() {
        return false;
    },
});

// 3. Patch the autocomplete component that shows the dropdown
patch(Many2XAutocomplete.prototype, {
    setup() {
        super.setup(...arguments);
        // Override props
        if (this.props) {
            this.props.quickCreate = false;
        }
    },

    get quickCreateEnabled() {
        return false;
    },

    // Some Odoo versions check this property
    get canQuickCreate() {
        return false;
    },
});
