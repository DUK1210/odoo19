{
    'name': 'Disable Quick Create',
    'version': '19.0.1.0.0',
    'summary': 'Globally disables Quick Create on Many2one and Many2many fields',
    'description': """
        Disable Quick Create
        ====================
        This module removes the "Quick Create" option (the ability to create a record 
        directly by typing its name in the dropdown) from all Many2one and Many2many tags fields.
        
        "Create and Edit" popup is preserved unless "no_create_edit" is set on the field.
    """,
    'category': 'Technical',
    'author': 'NEXERP PRIVATE LIMITED',
    'website': 'https://www.nexeerp.com',
    'license': 'LGPL-3',
    'depends': ['web'],
    'assets': {
        'web.assets_backend': [
            'nx_disable_quick_create/static/src/js/disable_quick_create.js',
        ],
    },
    'images': ['static/description/banner.png'],
    'installable': True,
    'auto_install': False,
}
